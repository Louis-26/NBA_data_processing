## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4,
  fig.align = "center"
)

## ----q1-----------------------------------------------------------------------
library(NBADP)
PER(lgdata = lg, regulardata = X2021to2022data, yrs = "2021-22", "LeBron James","LAL")

## ----q1a----------------------------------------------------------------------
library(corrplot)
numericVar <- which(sapply(datasets, FUN = is.numeric))
numVarNames <- names(numericVar)
datasetnumVar <- datasets[, numericVar]
cor_Mat <- cor(datasetnumVar, use = "pairwise.complete.obs")
cor_names <- names(sort(cor_Mat[, "salarya"], decreasing = TRUE))[1:20]
cor_Mat <- cor_Mat[cor_names, cor_names]
corrplot.mixed(cor_Mat, tl.pos = "lt")

## ----q1b----------------------------------------------------------------------
library(ggplot2)
ggplot(data = datasets, aes(x = TOV, y = salarya)) + geom_point() + 
  geom_smooth(formula = y ~ x, method = "loess")

## ----q1c----------------------------------------------------------------------
library(NBADP)
pred_salary(0.6, 3.9, 2.1, 0.4, 1.4, 6, 0, 0.8, 13.4, 1.4, 13.4, -2.9, 0.6)

## ----q2a----------------------------------------------------------------------
nba_win_rate(year = 2024, desc = TRUE)

## ----q3a----------------------------------------------------------------------
best_nba_player(top = 4, year = 2018)

## ---- func2-------------------------------------------------------------------
library(NBADP)
MVP.prediction()

## ---- func3-------------------------------------------------------------------
library(NBADP)
championship.Predict.2023()

## ---- func1-------------------------------------------------------------------
library(NBADP)
correlation.analysis()


## ----q21a---------------------------------------------------------------------
shot_visual(data1 = shot, team1 = "NOP",opponent1 = "NOP")

## ----q22a---------------------------------------------------------------------
player_visual(teamdata = GSW,"S. Curry","GSW")

## ----q23a---------------------------------------------------------------------
field_nba_player(index = 30, year = 2021, desc = TRUE)

## ---- q4a---------------------------------------------------------------------
library(NBADP)
Kawhi.Leonard.state.analysis(
  data.category = c("MIN", "PTS", "REB", "FGM"),
  month.range = c("October", "November", "December", "January", "February", "March","April")
)

## -----------------------------------------------------------------------------
DataSalariesRaw$salary <- as.numeric(gsub("[$,]", "", DataSalariesRaw$salary))
DataSalariesRaw$inflationAdjSalary <- as.numeric(gsub("[$,]", "", DataSalariesRaw$inflationAdjSalary))

