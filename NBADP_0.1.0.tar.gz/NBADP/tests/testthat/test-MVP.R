test_that("multiplication works", {
  expect_equal(is.vector(MVP.prediction()), TRUE)
})
