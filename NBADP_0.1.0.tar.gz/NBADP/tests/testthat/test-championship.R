test_that("multiplication works", {
  expect_equal(is.vector(championship.Predict.2023()),TRUE)
})
