test_that("multiplication works", {
  expect_equal(is.list(correlation.analysis()),TRUE)
})
